<?php
  // For now, index.php just redirects to browse.php, but you can change this
  // if you like.
$base_url = "http://localhost/login-code";
  header("Location: $base_url/browse.php");
?>