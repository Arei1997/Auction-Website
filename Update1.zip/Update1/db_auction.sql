-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 06, 2022 at 07:45 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_auction`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE IF NOT EXISTS `tbl_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(300) DEFAULT NULL,
  `email_address` varchar(300) DEFAULT NULL,
  `post_code` varchar(300) DEFAULT NULL,
  `password` varchar(300) DEFAULT NULL,
  `is_active` int(11) DEFAULT NULL,
  `address` varchar(500) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `username`, `email_address`, `post_code`, `password`, `is_active`, `address`) VALUES
(2, 'Username1', 'hjyuijk@dfdd.com', 'Abcd1234', '$2y$10$E9S4R3hqgmy.xisxstpwEeSzjZSBVTYhXC96tSbwZWf8k6ZrafDMy', 1, ''),
(3, 'Username1', 'hh', '', '$2y$10$xg1sgUTGJdOe4LlhWwrCGuy5JJK6vUBsEmUfq6iutPR3W3VpCbrlO', 1, ''),
(4, 'Username1', '', '', '$2y$10$W.slXHUam.jz8acoJ4yi7uMG4dumzae7mvKU44wlb.RqHbOZZJekS', 1, ''),
(5, '', '', '', '$2y$10$3ZUSR4awv14X0/llQY6ImeLK4Im9E8db7tdcsM97RqL5gefBTRde.', 1, ''),
(6, '', '', '', '$2y$10$o7YQFb3apoM//SFWOsVcxucmgE5FloQk2G0VP3TgoyCoZBOMF7fxG', 1, ''),
(7, 'User1', 'User1@email.com', 'aa1 111', '$2y$10$uXkrSA3qOyZ94eDYCtxRpeZ9t7ZmsqGbJy1XLx9GrS7L6SVuIdWUK', 1, ''),
(8, 'aaa', 'aa@aa.com', 'aa1 1aa', '$2y$10$iIINL93iK3A1L71GlARe.e05r2YiMoVM0H0mHAuASSo8V0vktM4ey', 1, 'aaa'),
(9, 'Username123', 'eeee@e.com', 'eeeeeeeeeeee', '$2y$10$.LM9rWR2MLkzYeuCrR025OUF.JdrlN2ambUANaD8mhTSWA/yqpmUe', 1, 'eee'),
(10, 'a123', 'asdsd@email.com', 'dsjfkdsf', '$2y$10$ArwO3HxmdtuNN.mZQhG7zuJAoXELevQ5GXEL73koH7A2Fez.dBole', 1, 'esfnkjrfdjk');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
